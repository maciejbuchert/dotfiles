<?php
#parse("PHP File Header.php")

namespace ${NAMESPACE};

use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

/**
 * Class ${CLASSNAME}
#if (${NAMESPACE}) * @package ${NAMESPACE}
#end
 */
class ${CLASSNAME} extends AbstractDb
{
    /**
     * @inheritDoc
     */
    public function _construct(): void
    {
        $this->_init('${TABLE}', '${PRIMARYKEY}');
    }
}

