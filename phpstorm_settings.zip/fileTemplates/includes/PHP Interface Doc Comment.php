/**
 * Interface ${NAME}
#if (${NAMESPACE}) * @package ${NAMESPACE}
#end
 */