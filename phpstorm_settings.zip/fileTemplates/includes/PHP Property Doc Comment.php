
/**
 * @var ${TYPE_HINT}
 */
