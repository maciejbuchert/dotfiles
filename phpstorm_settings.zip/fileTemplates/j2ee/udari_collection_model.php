<?php
#parse("PHP File Header.php")

namespace ${NAMESPACE};

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

/**
 * Class Collection
#if (${NAMESPACE}) * @package ${NAMESPACE}
#end
 */
class Collection extends AbstractCollection
{
    /**
     * @inheritDoc
     */
    public function _construct(): void
    {
        $this->_init(\\${MODEL}::class, \\${RESOURCEMODEL}::class);
    }
}
