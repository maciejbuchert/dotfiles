#set($ARRAY = $NAMESPACE.split("\\"))
#set($VENDOR = $ARRAY.get(0))
#set($MODULE = $ARRAY.get(1))
/**
 * Created by Ringier Axel Springer Tech
 * Date: ${DATE}
 *
 * @category    ${VENDOR}
 * @package     ${VENDOR}_${MODULE}
 * @author      Maciej Buchert <maciej.buchert@ringieraxelspringer.com>
 */