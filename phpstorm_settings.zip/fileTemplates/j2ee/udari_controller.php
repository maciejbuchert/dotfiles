<?php
#parse("PHP File Header.php")

namespace ${NAMESPACE};

use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
use ${CONTROLLER};


/**
 * Class ${CLASSNAME}
#if (${NAMESPACE}) * @package ${NAMESPACE}
#end
 */
class ${CLASSNAME} extends Action
{
    /**
     * @inheritDoc
     */
    public function execute()
    {
    }
}
