<?php
#parse("PHP File Header.php")

namespace ${NAMESPACE};

use Magento\Framework\Model\AbstractModel;

/**
 * Class ${CLASSNAME}
#if (${NAMESPACE}) * @package ${NAMESPACE}
#end
 */
class ${CLASSNAME} extends AbstractModel
{
    /**
     * @inheritDoc
     */
    public function _construct(): void
    {
        $this->_init(\\${RESOURCEMODEL}::class);
    }
}

